package com.eatwell.foodHQ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodHqApplicationTests {

	@Test
	void contextLoads() {
	}

}
