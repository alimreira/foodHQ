package com.eatwell.foodHQ.service;

public interface WaiterService {
}
