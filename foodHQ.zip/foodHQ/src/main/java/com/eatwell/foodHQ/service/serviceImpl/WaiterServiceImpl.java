package com.eatwell.foodHQ.service.serviceImpl;

public class WaiterServiceImpl {
}
