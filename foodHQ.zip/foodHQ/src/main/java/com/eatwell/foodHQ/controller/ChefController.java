package com.eatwell.foodHQ.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ChefController {

}
